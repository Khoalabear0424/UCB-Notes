alert('hi');

console.log($);