# Inquirer Intro

* [`basic.js`](basic.js)

## Instructions

* Spend a few moments studying the code with the person next to you. Be sure each of you understand:

  * How to install and incorporate the `inquirer` package.

  * How to create the variety of prompts offered by the package.

  * The significance of the `.then` function and the variable created (in this case `user`).
